<?php
if(session_status()==PHP_SESSION_NONE){
    session_start();
}

if(!isset($_SESSION['role']) || $_SESSION['role']!="siswa"){
    header("Location: ../login.php");
    exit;
}
?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Panel Siswa</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">

<link
href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
rel="stylesheet">

<style>

*{

margin:0;

padding:0;

box-sizing:border-box;

font-family:'Poppins',sans-serif;

}

body{

background:#f4f7fb;

overflow-x:hidden;

}

:root{

--primary:#2563eb;

--success:#16a34a;

--danger:#dc2626;

--warning:#f59e0b;

--dark:#1f2937;

}

/* ===========================
NAVBAR
=========================== */

.navbar{

height:70px;

background:white;

box-shadow:0 5px 20px rgba(0,0,0,.08);

padding:0 25px;

position:fixed;

top:0;

left:0;

right:0;

z-index:1000;

}

.navbar-brand{

font-size:34px;

font-weight:700;

color:var(--primary)!important;

}
.content{

    margin-top:90px;

    margin-left:260px;

    padding:25px;

    width:calc(100% - 260px);

}

.sidebar{

    position:fixed;

    top:70px;

    left:0;

    width:260px;

    height:calc(100vh - 70px);

    background:linear-gradient(180deg,#2563eb,#1d4ed8);

    display:flex;

    flex-direction:column;

    z-index:999;

}
/*======================================
SIDEBAR HEADER
======================================*/

.sidebar-header{

padding:30px 20px;

text-align:center;

border-bottom:1px solid rgba(255,255,255,.15);

}

.avatar{

width:90px;

height:90px;

margin:auto;

border-radius:50%;

background:#fff;

display:flex;

justify-content:center;

align-items:center;

font-size:40px;

color:#2563eb;

margin-bottom:15px;

box-shadow:0 10px 25px rgba(0,0,0,.15);

}

.sidebar-header h4{

color:#fff;

font-weight:700;

font-size:22px;

margin-bottom:5px;

}

.sidebar-header p{

color:rgba(255,255,255,.8);

margin:0;

}

/*======================================
MENU
======================================*/

.sidebar-menu{

flex:1;

padding:15px;

overflow-y:auto;

}

.sidebar-menu::-webkit-scrollbar{

width:6px;

}

.sidebar-menu::-webkit-scrollbar-thumb{

background:rgba(255,255,255,.3);

border-radius:20px;

}

.menu-title{

color:rgba(255,255,255,.65);

font-size:12px;

font-weight:700;

letter-spacing:1px;

padding:10px;

margin-bottom:10px;

}

.sidebar-menu a{

display:flex;

align-items:center;

gap:12px;

padding:14px 16px;

margin-bottom:8px;

text-decoration:none;

color:#fff;

border-radius:12px;

transition:.3s;

font-weight:600;

}

.sidebar-menu a i{

width:22px;

text-align:center;

font-size:17px;

}

.sidebar-menu a:hover{

background:rgba(255,255,255,.15);

padding-left:22px;

}

.sidebar-menu a.active{

background:#fff;

color:#2563eb;

box-shadow:0 8px 20px rgba(0,0,0,.15);

}

/*======================================
SIDEBAR FOOTER
======================================*/
.sidebar-footer{

    margin-top:auto;

    padding:18px;

    border-top:1px solid rgba(255,255,255,.15);

    background:transparent;

}

.logout-btn{

    display:flex;

    justify-content:center;

    align-items:center;

    gap:10px;

    width:100%;

    padding:14px;

    background:#ef4444;

    color:#fff;

    text-decoration:none;

    border-radius:12px;

    font-weight:600;

    transition:.3s;

}
.logout-btn:hover{

background:#dc2626;

color:#fff;

transform:translateY(-2px);

}

/*======================================
CARD
======================================*/

.card{

border:none;

border-radius:20px;

box-shadow:0 10px 25px rgba(0,0,0,.08);

}

.card-header{

background:#fff;

border-bottom:none;

font-weight:700;

font-size:18px;

padding:20px 25px;

}

.card-body{

padding:25px;

}

/*======================================
STATISTIK CARD
======================================*/

.stat-card{

position:relative;

border-radius:20px;

padding:22px;

color:#fff;

overflow:hidden;

transition:.3s;

}

.stat-card:hover{

transform:translateY(-5px);

}

.bg-primary-gradient{

background:linear-gradient(135deg,#2563eb,#1d4ed8);

}

.bg-success-gradient{

background:linear-gradient(135deg,#16a34a,#15803d);

}

.bg-warning-gradient{

background:linear-gradient(135deg,#f59e0b,#d97706);

}

.stat-card h2{

font-size:34px;

font-weight:700;

margin:10px 0;

}

.stat-card .icon{

position:absolute;

right:20px;

top:20px;

font-size:55px;

opacity:.15;

}
/*======================================
TABLE
======================================*/

.table{

margin-bottom:0;

}

.table thead{

background:#2563eb;

color:#fff;

}

.table thead th{

padding:15px;

border:none;

font-weight:600;

vertical-align:middle;

}

.table tbody td{

padding:14px;

vertical-align:middle;

}

.table tbody tr:hover{

background:#f8fbff;

}

/*======================================
FORM
======================================*/

.form-control,
.form-select{

height:48px;

border-radius:12px;

border:1px solid #d1d5db;

}

.form-control:focus,
.form-select:focus{

border-color:#2563eb;

box-shadow:0 0 0 .2rem rgba(37,99,235,.15);

}

textarea.form-control{

height:auto;

}

/*======================================
BUTTON
======================================*/

.btn{

border-radius:12px;

font-weight:600;

padding:10px 18px;

transition:.3s;

}

.btn:hover{

transform:translateY(-2px);

}

/*======================================
BADGE
======================================*/

.badge{

padding:8px 15px;

border-radius:30px;

font-size:12px;

}

/*======================================
RESPONSIVE
======================================*/

@media (max-width:992px){

.sidebar{

left:-260px;

transition:.3s;

}

.content{

margin-left:0;

width:100%;

}

}

@media(max-width:768px){

.content{

padding:15px;

}

.navbar-brand{

font-size:26px;

}

}

/*======================================
SCROLLBAR
======================================*/

::-webkit-scrollbar{

width:7px;

}

::-webkit-scrollbar-thumb{

background:#cbd5e1;

border-radius:20px;

}

::-webkit-scrollbar-track{

background:#f8fafc;

}

</style>

</head>

<body>

<!-- ==========================
     NAVBAR
========================== -->

<nav class="navbar navbar-expand-lg">

<div class="container-fluid">

<a class="navbar-brand" href="index.php">

<i class="fa-solid fa-qrcode"></i>

Sistem Absensi QR

</a>

<div class="ms-auto">

<div class="dropdown">

<a
class="nav-link dropdown-toggle fw-semibold"
href="#"
data-bs-toggle="dropdown">

<i class="fa-solid fa-user"></i>

<?= htmlspecialchars($_SESSION['nama']); ?>

</a>

<ul class="dropdown-menu dropdown-menu-end">

<li>

<h6 class="dropdown-header">

<?= htmlspecialchars($_SESSION['nama']); ?>

</h6>

</li>

<li>

<span class="dropdown-item-text">
Siswa

</span>

</li>

<li><hr class="dropdown-divider"></li>

<li>

<a
class="dropdown-item text-danger"
href="../logout.php">

<i class="fa-solid fa-right-from-bracket me-2"></i>

Logout

</a>

</li>

</ul>

</div>

</div>

</div>

</nav>